package es.gdebustamante.inadraft.framework.ui.view.base

import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModel

abstract class BaseActivity<TypeViewModel : ViewModel> : AppCompatActivity() {

//    private val viewModel : TypeViewModel by viewModels()
//    abstract fun getToolbarBase() : Toolbar?
}