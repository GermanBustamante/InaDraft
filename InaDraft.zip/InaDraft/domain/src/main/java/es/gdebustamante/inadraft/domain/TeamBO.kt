package es.gdebustamante.inadraft.domain

data class TeamBO(
    val id : Int,
    val name : String,
    val shield : String
)